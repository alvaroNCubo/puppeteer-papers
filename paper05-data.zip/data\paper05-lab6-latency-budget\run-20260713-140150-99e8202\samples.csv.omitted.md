# Lab 6 — `samples.csv` (raw per-event latency) omitted from this archive

`samples.csv` for Lab 6 (`paper05-lab6-latency-budget`) is the raw per-append
latency log: **~500,000 rows (≈60 MB)**. It is omitted here to keep the archive
lightweight.

**The aggregated results Paper 5 cites** (§5.5/§5.6 — p50/p95/p99 per backend
and the RDBMS-to-FileSystem ratios) are in this same directory:
`summary.csv` and `headline.md`.

**To regenerate the raw samples**, run the lab against the published runtime
commit `99e8202` (one durable commit per append, N = 100 000 × 5 reps):

- Lab source: `labs/paper05-lab6-latency-budget/` (included in this archive) —
  canonical: <https://github.com/alvaroNCubo/puppeteer-papers/tree/main/labs/paper05-lab6-latency-budget>
- Runtime: <https://github.com/alvaroNCubo/puppeteer/tree/99e8202c808c3d79ca7b1dfbdae0ffb7872c940e>

The same holds for the other labs' raw per-event `samples.csv` where present; the
summaries and headlines in each data directory carry the figures the paper reports.
